
const navBar = document.getElementById('navbar__list')
const navMenu = document.getElementsByClassName('page__header')
const sections = document.querySelectorAll('section')

// console.log(sections);



// navMenu.item(0).style.backgroundColor = 'rgba(0,13,60,1)';
// navBar.style.padding = '10px';
// navBar.style.backgroundColor = '';
// navBar.style.display = 'flex';

sections.forEach(section => {
  // console.log(section.id,section.dataset.nav);
  const li = document.createElement('li');
  li.innerHTML = `<a class="menu__link" id="${section.id}__nav" data-nav="#${section.dataset.nav}" href="#${section.id}"> ${section.dataset.nav}</a>`
  navBar.appendChild(li)

})



window.addEventListener('scroll', () => {
  const width = window.innerWidth;
  navBar.style.flexWrap = width < 876 ? 'wrap' : 'nowrap';
  const sections = document.querySelectorAll('section');
  sections.forEach(section => {
    // console.log(navBar.offsetHeight,section.getBoundingClientRect().top);
    const boundingClient = section.getBoundingClientRect().top;
    const role = boundingClient  >= -20 && boundingClient <= 100;
    const activeNav = document.getElementById(section.id + '__nav');
    section.classList.toggle('your-active-class', role);
    console.log();
    section.style.paddingTop = `${ navBar.offsetHeight - (width < 434? 10:40)}px`
      activeNav.classList.toggle('active',role)
       activeNav.style.backgroundColor = role ? 'black' : 'white';
       activeNav.style.color = role?  'white': 'black'
  });
});

// const navMouseOver = (id) => {
//   const allLi = document.querySelectorAll('li');
//   allLi.forEach(e => {
//     e.style.backgroundColor = e.firstChild.id === id ? '#cc1' : '';
//     // setTimeout(() => e.style.backgroundColor = '', 1000);
//   })

// }

// navBar.childNodes.forEach((e) => e.addEventListener("mouseover",
//   () => navMouseOver(e.firstChild.id)),
// );



//smoth Scroll to section 
function smoothScroll() {
  navBar.querySelectorAll('.menu__link').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth',
      });
    });
  });
}

smoothScroll();
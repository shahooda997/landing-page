# Landing Page Project

This project uses JavaScript and other cool technology to dynamically construct a navigation bar for a landing page.

## Table of Contents

* [Project Title](#Landing-Page-Project)
* [Instructions](#instructions)
* [Table of Contents](#table-of-Contents)
* [Installation](#installation)
* [Usage](#usage)
* [Development](#development)
* [License & Copyright](#License-&-Copyright)


## Instructions

[(Back to top)](#table-of-Contents)

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open `js/app.js` and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.

## installation

[(Back to top)](#table-of-Contents)

We install the project to our PC from a link in Udacity website and then using our github account we download it as a ZIP file. 

## usage

[(Back to top)](#table-of-Contents)

After the installation, we extract the file from a ZIP file and open it by VS code program.

## development

[(Back to top)](#table-of-Contents)

```JS Version: ES2015/ES6```
  
```JS Standard: ESlint```

### The project contains 4 files :

### css /
- style.css

### js /
- app.js

### index.html

### README.md

- In CSS there is some changes that i done to be in a good style.

-In HTML file there is not a lot of modification done just add one more section to the page and link between html and Javascript file.

- There was a lot of work done in app.js, where the majority of it was done.

## License-&-Copyright

[(Back to top)](#table-of-Contents)

***© Udacity - Modified By Shahad Al Harthi.***
